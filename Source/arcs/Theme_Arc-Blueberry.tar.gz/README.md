# Arc Blueberry Theme for HyDE

A dark theme with purple, pink and cyan gradient accents inspired by omarchy's arc-blueberry theme.

## Color Palette

- **Background**: `#111422` - Deep dark blue
- **Foreground**: `#bcc1dc` - Light purple-gray
- **Primary**: `#F38CEC` - Bright pink
- **Secondary**: `#8eb0e6` - Sky blue
- **Accent**: `#69c3ff` - Cyan
- **Inactive**: `#3c4776` - Dark blue-gray

## Features

- Smooth animations with easeOut bezier curves
- Cyan glow shadow effects
- Purple to cyan gradient borders
- Optimized blur settings

## Credits

Based on omarchy's arc-blueberry theme
Adapted for HyDE by Tonymartos
